# Patterns_Estruturais
Atividades
