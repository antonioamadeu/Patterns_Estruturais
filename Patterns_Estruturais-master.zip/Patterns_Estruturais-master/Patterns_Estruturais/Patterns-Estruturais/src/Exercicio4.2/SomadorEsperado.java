package Exercicio4_2;

public interface SomadorEsperado {
	/** Soma todos os números de um vetor. */
	int somaVetor(int[] vetor);
}
