package Exercicio6_1;

public interface MensagemDoDia {
	/** Imprime. */
	void imprimir();
}
