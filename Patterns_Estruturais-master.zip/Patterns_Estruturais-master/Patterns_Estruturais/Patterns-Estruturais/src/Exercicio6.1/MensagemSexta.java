package Exercicio6_1;

public class MensagemSexta implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � sexta-feira.");
	}
}
