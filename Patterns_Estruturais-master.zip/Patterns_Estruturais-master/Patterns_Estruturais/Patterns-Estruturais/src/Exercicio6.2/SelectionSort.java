package Exercicio6_2;

public interface SelectionSort {
	//Ordena um vetor de doubles.
	void sort(double[] a);
}
