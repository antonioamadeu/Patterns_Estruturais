package Ex9_1;

public class Moedas {
	private Moedas moeda;
	public Moedas() {
		
		
	}
	public Moedas getMoeda() {
		return moeda;
	}
	public void setMoeda(Moedas moeda) {
		this.moeda = moeda;
	}

}




	//João Victor Telles Gementi 
	//RA 81616650

