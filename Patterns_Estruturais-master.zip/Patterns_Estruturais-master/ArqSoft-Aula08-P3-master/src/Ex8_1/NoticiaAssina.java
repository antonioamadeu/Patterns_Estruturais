package Ex8_1;

public class NoticiaAssina{
	public NoticiaAssina(){
		
		
		
	}
}



	//João Victor Telles Gementi 
	//RA 81616650

