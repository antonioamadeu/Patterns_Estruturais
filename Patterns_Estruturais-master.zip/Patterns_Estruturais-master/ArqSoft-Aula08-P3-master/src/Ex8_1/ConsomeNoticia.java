package Ex8_1;

public interface ConsomeNoticia {     
	public void notificaNoticia(String textoNoticia, int dia,     int mes, String topico); } 

	//João Victor Telles Gementi 
	//RA 81616650

