package Ex8_1;

public abstract class Noticiario {
	
	public abstract void notificaNoticia(String textoNoticia, int dia,   int mes, String topico); 

}



	//João Victor Telles Gementi 
	//RA 81616650

