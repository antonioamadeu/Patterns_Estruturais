# Patterns_Estruturais
Exercícios sobre Patterns Estruturais
