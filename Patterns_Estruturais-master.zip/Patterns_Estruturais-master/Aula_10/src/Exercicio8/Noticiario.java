package Exercicio8;

/**
 * 
 * @author Allan Samey Cordeiro Ramos - RA:201516605 - Turma:SIN3AN-MCA
 * 			
 *
 */

public abstract class Noticiario {
	public abstract void notificaNoticia(String textoNoticia, int dia, int mes, String topico);
}
