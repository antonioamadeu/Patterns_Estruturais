package Exercicio9_1;

/**
 * 
 * @author Allan Samey Cordeiro Ramos - RA:201516605 - Turma:SIN3AN-MCA
 * 			
 *
 */

public interface Slot {
	public double recebeMoeda(int m);
	public void setSlot(Slot s);
}
